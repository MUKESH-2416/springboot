package com.excel.mavenex;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MavenexApplicationTests {

	@Test
	void contextLoads() {
	}

}
