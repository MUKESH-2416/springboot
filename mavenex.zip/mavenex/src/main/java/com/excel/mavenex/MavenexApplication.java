package com.excel.mavenex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MavenexApplication {

	public static void main(String[] args) {
		SpringApplication.run(MavenexApplication.class, args);
	}

}
